#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/launcher"
echo ">> Building GNUClient Launcher (release)..."
cargo build --release
echo ">> Done. Binary: $(pwd)/target/release/gnuclient-launcher"