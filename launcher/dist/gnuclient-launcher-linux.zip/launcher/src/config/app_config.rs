use std::path::{Path, PathBuf};

use anyhow::Result;
use serde::{Deserialize, Serialize};

use crate::minecraft::instance::GameInstanceConfig;

/// Central launcher configuration, persisted as TOML in the launcher data dir.
#[derive(Debug, Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Config {
    /// Root directory where instances, mods, packs, and runtimes live.
    pub data_dir: PathBuf,
    /// The currently selected instance id.
    pub active_instance: Option<String>,
    /// Persisted per-instance settings.
    pub instances: Vec<GameInstanceConfig>,
    /// Default JVM arguments applied to new instances.
    pub default_jvm_args: String,
    /// Max concurrent downloads.
    pub max_concurrent_downloads: usize,
    /// Whether to auto-install Java 8 when missing.
    pub auto_install_java: bool,
    /// Selected theme ("onyx", "aurora", "obsidian").
    pub theme: String,
}

impl Default for Config {
    fn default() -> Self {
        Self {
            data_dir: default_data_dir(),
            active_instance: None,
            instances: Vec::new(),
            default_jvm_args: DEFAULT_JVM_ARGS.to_string(),
            max_concurrent_downloads: 8,
            auto_install_java: true,
            theme: "onyx".to_string(),
        }
    }
}

pub const DEFAULT_JVM_ARGS: &str =
    "-Xms1G -Xmx2G -XX:+UseG1GC -XX:+UnlockExperimentalVMOptions -XX:MaxGCPauseMillis=50";

/// Path to the launcher's data directory (~/Library/Application Support/gnuclient-launcher on macOS).
pub fn default_data_dir() -> PathBuf {
    let base = dirs::data_dir().unwrap_or_else(|| PathBuf::from("."));
    base.join("gnuclient-launcher")
}

impl Config {
    /// Load config from the default location, creating a fresh one if absent.
    pub fn load() -> Result<Self> {
        let path = config_path();
        if path.exists() {
            let raw = std::fs::read_to_string(&path)?;
            let cfg: Config = toml::from_str(&raw)?;
            Ok(cfg)
        } else {
            let cfg = Config::default();
            let _ = cfg.save(); // best-effort
            Ok(cfg)
        }
    }

    pub fn save(&self) -> Result<()> {
        let path = config_path();
        if let Some(parent) = path.parent() {
            std::fs::create_dir_all(parent)?;
        }
        let raw = toml::to_string_pretty(self)?;
        std::fs::write(path, raw)?;
        Ok(())
    }

    /// Ensure the data dir exists and return it.
    pub fn ensure_data_dir(&self) -> Result<PathBuf> {
        std::fs::create_dir_all(&self.data_dir)?;
        Ok(self.data_dir.clone())
    }

    pub fn instance_by_id(&self, id: &str) -> Option<&GameInstanceConfig> {
        self.instances.iter().find(|i| i.id == id)
    }

    pub fn active(&self) -> Option<&GameInstanceConfig> {
        let id = self.active_instance.as_ref()?;
        self.instance_by_id(id)
    }

    pub fn upsert_instance(&mut self, inst: GameInstanceConfig) {
        if let Some(existing) = self.instances.iter_mut().find(|i| i.id == inst.id) {
            *existing = inst;
        } else {
            self.instances.push(inst);
        }
        let _ = self.save();
    }

    pub fn remove_instance(&mut self, id: &str) {
        self.instances.retain(|i| i.id != id);
        if self.active_instance.as_deref() == Some(id) {
            self.active_instance = self.instances.first().map(|i| i.id.clone());
        }
        let _ = self.save();
    }
}

fn config_path() -> PathBuf {
    let dir = default_data_dir();
    dir.join("config.toml")
}

pub fn as_abs(path: impl AsRef<Path>) -> PathBuf {
    let p = path.as_ref();
    if p.is_absolute() {
        p.to_path_buf()
    } else {
        std::env::current_dir().unwrap_or_default().join(p)
    }
}
