use std::path::{Path, PathBuf};

use anyhow::Result;
use serde::{Deserialize, Serialize};

use crate::config::app_config::default_data_dir;

/// A persisted Minecraft account.
#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Account {
    pub id: String,
    pub username: String,
    pub msa_refresh_token: String,
    pub mc_uuid: String,
    pub mc_access_token: String,
    pub last_login: Option<String>,
}

impl Account {
    pub fn is_online(&self) -> bool {
        !self.mc_access_token.is_empty()
    }
}

/// Load all accounts from the accounts store.
pub fn load_accounts() -> Result<Vec<Account>> {
    let path = accounts_path();
    if !path.exists() {
        return Ok(Vec::new());
    }
    let raw = std::fs::read_to_string(&path)?;
    let accounts: Vec<Account> = serde_json::from_str(&raw)?;
    Ok(accounts)
}

/// Persist the account list.
pub fn save_accounts(accounts: &[Account]) -> Result<()> {
    let path = accounts_path();
    if let Some(parent) = path.parent() {
        std::fs::create_dir_all(parent)?;
    }
    let raw = serde_json::to_string_pretty(accounts)?;
    std::fs::write(path, raw)?;
    Ok(())
}

/// Store a sensitive secret (e.g. access token) in the OS keychain on macOS,
/// falling back to a file in a restricted-permission dir elsewhere.
pub fn store_secret(key: &str, value: &str) -> Result<()> {
    #[cfg(target_os = "macos")]
    {
        use security_framework::os::macos::keychain::SecKeychain;

        let keychain = SecKeychain::default()?;
        let service = "gnuclient-launcher";
        keychain.set_generic_password(service, key, value.as_bytes())?;
        Ok(())
    }
    #[cfg(not(target_os = "macos"))]
    {
        let path = secrets_dir().join(key);
        std::fs::create_dir_all(secrets_dir())?;
        std::fs::write(path, value)?;
        Ok(())
    }
}

/// Retrieve a secret from the keychain (or fallback file).
pub fn load_secret(key: &str) -> Result<Option<String>> {
    #[cfg(target_os = "macos")]
    {
        use security_framework::os::macos::keychain::SecKeychain;

        let keychain = SecKeychain::default()?;
        match keychain.find_generic_password("gnuclient-launcher", key) {
            Ok((data, _)) => Ok(Some(String::from_utf8_lossy(&data).to_string())),
            Err(_) => Ok(None),
        }
    }
    #[cfg(not(target_os = "macos"))]
    {
        let path = secrets_dir().join(key);
        if path.exists() {
            Ok(Some(std::fs::read_to_string(path)?))
        } else {
            Ok(None)
        }
    }
}

fn accounts_path() -> PathBuf {
    default_data_dir().join("accounts.json")
}

#[cfg(not(target_os = "macos"))]
fn secrets_dir() -> PathBuf {
    default_data_dir().join("secrets")
}

pub fn as_abs_path(p: &Path) -> PathBuf {
    if p.is_absolute() {
        p.to_path_buf()
    } else {
        default_data_dir().join(p)
    }
}
