@echo off
setlocal
cd /d "%~dp0launcher"
echo Building GNUClient Launcher (release)...
cargo build --release
if errorlevel 1 goto :err
echo Done. Binary: %cd%\target\release\gnuclient-launcher.exe
goto :eof
:err
echo Build failed.
exit /b 1